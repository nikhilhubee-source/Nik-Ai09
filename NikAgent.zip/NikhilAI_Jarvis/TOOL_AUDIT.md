# Tool Callability Audit — NIKHILAI

**Date:** 2026-10-10  ·  **Tools:** 77  ·  **Verdict:** PASS ✅

- ✅ callable: **77**
- 🟡 warn: **0**
- 🔴 broken: **0**

Har tool ko LLM ki tarah invoke kiya gaya (`ainvoke` + schema-validated args). Side-effect wale tools schema-check hote hain (asli call `--live-dangerous` se).

| # | group | tool | status | evidence |
|---|-------|------|--------|----------|
| 1 | code | `code_engine` | ✅ | schema ok • call skipped (side-effect) • args=['language', 'run', 'save_as', 'task'] |
| 2 | code | `create_project` | ✅ | schema ok • call skipped (side-effect) • args=['description', 'language', 'name'] |
| 3 | code | `install_package` | ✅ | schema ok • call skipped (side-effect) • args=['package'] |
| 4 | code | `run_python` | ✅ | schema ok • call skipped (side-effect) • args=['code'] |
| 5 | code | `run_script_file` | ✅ | schema ok • call skipped (side-effect) • args=['path', 'script_args'] |
| 6 | desktop | `append_note` | ✅ | schema ok • call skipped (side-effect) • args=['content', 'name'] |
| 7 | desktop | `close_app` | ✅ | schema ok • call skipped (side-effect) • args=['window_title'] |
| 8 | desktop | `control_volume` | ✅ | schema ok • call skipped (side-effect) • args=['action'] |
| 9 | desktop | `find_apps_tool` | ✅ | 2ms • invocation succeeded (176 output chars; content redacted) |
| 10 | desktop | `find_file` | ✅ | 13ms • invocation succeeded (78 output chars; content redacted) |
| 11 | desktop | `find_files` | ✅ | 151ms • invocation succeeded (1105 output chars; content redacted) |
| 12 | desktop | `folder_file` | ✅ | schema ok • call skipped (side-effect) • args=['command'] |
| 13 | desktop | `grant_exec_approval` | ✅ | schema ok • call skipped (side-effect) • args=- |
| 14 | desktop | `list_apps` | ✅ | 1ms • invocation succeeded (14 output chars; content redacted) |
| 15 | desktop | `list_dir` | ✅ | 1ms • invocation succeeded (627 output chars; content redacted) |
| 16 | desktop | `list_notes` | ✅ | 1ms • invocation succeeded (184 output chars; content redacted) |
| 17 | desktop | `list_windows` | ✅ | 1ms • invocation succeeded (77 output chars; content redacted) |
| 18 | desktop | `open_any_app` | ✅ | schema ok • call skipped (side-effect) • args=['query'] |
| 19 | desktop | `open_app` | ✅ | schema ok • call skipped (side-effect) • args=['app_title'] |
| 20 | desktop | `open_path` | ✅ | schema ok • call skipped (side-effect) • args=['app', 'path'] |
| 21 | desktop | `play_file` | ✅ | schema ok • call skipped (side-effect) • args=['name'] |
| 22 | desktop | `press_hotkey` | ✅ | schema ok • call skipped (side-effect) • args=['keys'] |
| 23 | desktop | `process_input` | ✅ | schema ok • call skipped (side-effect) • args=['pid', 'text'] |
| 24 | desktop | `process_list` | ✅ | 1ms • invocation succeeded (41 output chars; content redacted) |
| 25 | desktop | `process_logs` | ✅ | 1ms • invocation succeeded (40 output chars; content redacted) |
| 26 | desktop | `process_stop` | ✅ | schema ok • call skipped (side-effect) • args=['force', 'pid'] |
| 27 | desktop | `read_file` | ✅ | 183ms • invocation succeeded (288 output chars; content redacted) |
| 28 | desktop | `read_note` | ✅ | 3ms • invocation succeeded (42 output chars; content redacted) |
| 29 | desktop | `recent_files` | ✅ | 1ms • invocation succeeded (1548 output chars; content redacted) |
| 30 | desktop | `refresh_app_index` | ✅ | schema ok • call skipped (side-effect) • args=- |
| 31 | desktop | `run_shell_command` | ✅ | schema ok • call skipped (side-effect) • args=['background', 'command', 'confirmed', 'cwd', 'name', 'timeout'] |
| 32 | desktop | `save_note` | ✅ | schema ok • call skipped (side-effect) • args=['as_txt', 'content', 'name', 'open_in_notepad', 'tags'] |
| 33 | desktop | `search_inside_files` | ✅ | 62ms • invocation succeeded (347 output chars; content redacted) |
| 34 | desktop | `search_notes` | ✅ | 2ms • invocation succeeded (36 output chars; content redacted) |
| 35 | desktop | `start_background_process` | ✅ | schema ok • call skipped (side-effect) • args=['command', 'cwd', 'name'] |
| 36 | desktop | `system_info` | ✅ | 201ms • invocation succeeded (233 output chars; content redacted) |
| 37 | desktop | `take_screenshot` | ✅ | schema ok • call skipped (side-effect) • args=['name'] |
| 38 | desktop | `type_text` | ✅ | schema ok • call skipped (side-effect) • args=['text'] |
| 39 | desktop | `write_file` | ✅ | schema ok • call skipped (side-effect) • args=['content', 'path'] |
| 40 | memory | `conversation_history` | ✅ | 2ms • invocation succeeded (956 output chars; content redacted) |
| 41 | memory | `memory_compact` | ✅ | schema ok • call skipped (side-effect) • args=- |
| 42 | memory | `memory_stats` | ✅ | 1ms • invocation succeeded (79 output chars; content redacted) |
| 43 | memory | `recall_facts` | ✅ | 2ms • invocation succeeded (2411 output chars; content redacted) |
| 44 | memory | `remember_fact` | ✅ | schema ok • call skipped (side-effect) • args=['fact', 'key', 'tags'] |
| 45 | ops | `cancel_automation` | ✅ | schema ok • call skipped (side-effect) • args=['ident'] |
| 46 | ops | `clear_cache_tool` | ✅ | schema ok • call skipped (side-effect) • args=['dry_run', 'scope'] |
| 47 | ops | `clear_process_tool` | ✅ | schema ok • call skipped (side-effect) • args=['force', 'name', 'pid'] |
| 48 | ops | `create_automation` | ✅ | schema ok • call skipped (side-effect) • args=['enable', 'schedule', 'task'] |
| 49 | ops | `full_system_status` | ✅ | 3ms • invocation succeeded (471 output chars; content redacted) |
| 50 | ops | `list_automations` | ✅ | 1ms • invocation succeeded (68 output chars; content redacted) |
| 51 | ops | `refresh_system_tool` | ✅ | schema ok • call skipped (side-effect) • args=['clear_caches'] |
| 52 | ops | `reload_config_tool` | ✅ | schema ok • call skipped (side-effect) • args=- |
| 53 | ops | `restart_jarvis_tool` | ✅ | schema ok • call skipped (side-effect) • args=- |
| 54 | ops | `run_automation` | ✅ | schema ok • call skipped (side-effect) • args=['ident'] |
| 55 | ops | `toggle_automation` | ✅ | schema ok • call skipped (side-effect) • args=['enabled', 'ident'] |
| 56 | research | `browser_cli` | ✅ | 19ms • invocation succeeded (204 output chars; content redacted) |
| 57 | research | `browser_close` | ✅ | schema ok • call skipped (side-effect) • args=- |
| 58 | research | `browser_doctor` | ✅ | 1ms • invocation succeeded (229 output chars; content redacted) |
| 59 | research | `browser_research` | ✅ | schema ok • call skipped (side-effect) • args=['fields', 'max_parallel', 'save_note_as', 'sites', 'task'] |
| 60 | research | `browser_screenshot` | ✅ | schema ok • call skipped (side-effect) • args=['name'] |
| 61 | research | `browser_task` | ✅ | schema ok • call skipped (side-effect) • args=['max_steps', 'output_fields', 'save_note_as', 'start_url', 'tas |
| 62 | research | `deep_research` | ✅ | schema ok • call skipped (side-effect) • args=['max_pages', 'query', 'sites'] |
| 63 | research | `fetch_page` | ✅ | 173ms • invocation succeeded (197 output chars; content redacted) |
| 64 | research | `get_current_datetime` | ✅ | 1ms • invocation succeeded (42 output chars; content redacted) |
| 65 | research | `get_weather` | ✅ | 635ms • invocation succeeded (58 output chars; content redacted) |
| 66 | research | `google_search` | ✅ | 2342ms • invocation succeeded (346 output chars; content redacted) |
| 67 | runtime | `python_repl` | ✅ | schema ok • call skipped (side-effect) • args=['code'] |
| 68 | runtime | `repl_reset` | ✅ | schema ok • call skipped (side-effect) • args=- |
| 69 | runtime | `repl_state` | ✅ | 1ms • invocation succeeded (155 output chars; content redacted) |
| 70 | runtime | `run_python_isolated` | ✅ | schema ok • call skipped (side-effect) • args=['code', 'timeout'] |
| 71 | runtime | `session_context` | ✅ | 1ms • invocation succeeded (732 output chars; content redacted) |
| 72 | runtime | `session_note` | ✅ | schema ok • call skipped (side-effect) • args=['note'] |
| 73 | runtime | `set_pending_steps` | ✅ | schema ok • call skipped (side-effect) • args=['steps'] |
| 74 | runtime | `set_preference` | ✅ | schema ok • call skipped (side-effect) • args=['key', 'value'] |
| 75 | runtime | `set_workspace` | ✅ | schema ok • call skipped (side-effect) • args=['path'] |
| 76 | skills | `list_skills` | ✅ | 1ms • invocation succeeded (376 output chars; content redacted) |
| 77 | skills | `read_skill` | ✅ | 1ms • invocation succeeded (1211 output chars; content redacted) |

Regenerate: `python scripts/audit_tools.py --report TOOL_AUDIT.md`

"""
jarvis/api/server.py — FastAPI server + built-in web console
===========================================================

Endpoints:
  GET  /                → web console (single-file HTML, inline CSS/JS — preview-safe)
  POST /chat            → {message, session_id} → answers (LangGraph supervisor)
  POST /task            → raw graph run + poora state JSON
  GET  /stream?message= → Server-Sent Events: live node-by-node progress
  GET  /health          → provider / tools / browser / memory status
  GET  /notes           → saved notes list
  GET  /graph           → mermaid + ASCII architecture
  GET  /tools           → tool catalogue (kaun kaun se tool wired hain)

Run:
  python -m jarvis serve                 # local-only by default
  python -m jarvis serve 0.0.0.0 8000   # token + HTTPS/TLS proxy required
"""
from __future__ import annotations

import asyncio
import hmac
import ipaddress
import json
import threading
import time
from collections import deque
from typing import Any

from ..config import (
    API_AUTH_TOKEN,
    API_HOST,
    API_PORT,
    API_TRUST_PROXY_HEADERS,
    ASSISTANT_NAME,
)
from ..graph.build import graph_mermaid, graph_summary
from ..memory.store import get_memory
from ..runtime.agent import run_agent

try:
    from fastapi import FastAPI, Query, Request
    from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
    fastapi_available = True
except Exception:  # pragma: no cover
    fastapi_available = False
    FastAPI = None  # type: ignore
    HTMLResponse = JSONResponse = StreamingResponse = None  # type: ignore


def _status() -> dict[str, Any]:
    from ..runtime.status import agent_status

    current = agent_status(compact=True, surface="API/server")
    return {
        "assistant": current["assistant"],
        "owner": current["owner"],
        "status": current["status"],
        "interface": "API/server",
        "provider": current["provider"],
        "configured_provider": current["configured_provider"],
        "provider_status": current.get("provider_status", "unknown"),
        "model": current["model"],
        "fast_model": current["fast_model"],
        "model_route_reason": current.get("model_route_reason", ""),
        "offline_demo": current["offline"],
        "connectivity_tested": current["connection_tested"],
        "browser": current["browser"],
        "browser_use": current["browser_cli"] or "browser-use" in current["browser"],
        "browser_use_cli": current["browser_cli"],
        "livekit": current["livekit"],
        "livekit_status": current["livekit_status"],
        "telegram": current["telegram"],
        "telegram_status": current["telegram_status"],
        "workspace": current["workspace"],
        "memory": current.get("memory_stats", {}),
        "tools": current.get("tool_count", 0),
        "tools_status": current.get("tools_status", "unknown"),
        "automations": current["automations"],
    }


if fastapi_available:
    app = FastAPI(title=f"{ASSISTANT_NAME} — NikhilAI ", version="2.0")

    _AUTH_MAX_FAILURES = 5
    _AUTH_WINDOW_SECONDS = 300.0
    _AUTH_MAX_CLIENTS = 2048
    _AUTH_FAILURES: dict[str, deque[float]] = {}
    _AUTH_FAILURES_LOCK = threading.Lock()

    def _host_is_network_exposed(raw_host: str) -> bool:
        host = str(raw_host or "127.0.0.1").strip().strip("[]").rstrip(".").lower()
        if host in {"localhost", "ip6-localhost", "localhost.localdomain"}:
            return False
        try:
            address = ipaddress.ip_address(host.split("%", 1)[0])
        except ValueError:
            # Hostnames and unclassified addresses are treated as public, not trusted local.
            return True
        if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped:
            address = address.ipv4_mapped
        return not address.is_loopback

    def _network_exposed(request: Request | None = None) -> bool:
        """Classify the real ASGI bind host; an explicit CLI --host must not bypass auth."""
        if API_TRUST_PROXY_HEADERS:
            # The app is behind a trusted proxy; treat it as network-facing even if its socket is loopback.
            return True
        server = request.scope.get("server") if request is not None else None
        if isinstance(server, (tuple, list)) and server:
            runtime_host = str(server[0] or "").strip()
            if runtime_host and runtime_host.lower() not in {"testserver", "unknown"}:
                return _host_is_network_exposed(runtime_host)
        return _host_is_network_exposed(API_HOST or "127.0.0.1")

    def _request_is_https(request: Request) -> bool:
        if request.url.scheme.lower() == "https":
            return True
        if API_TRUST_PROXY_HEADERS:
            forwarded = request.headers.get("x-forwarded-proto", "").split(",", 1)[0].strip().lower()
            return forwarded == "https"
        return False

    def _auth_client_key(request: Request) -> str:
        # Use the socket peer, not arbitrary X-Forwarded-For text, to prevent rate-limit spoofing.
        client = request.client
        return (str(client.host) if client and client.host else "unknown")[:128]

    def _auth_retry_after(request: Request) -> int:
        now = time.monotonic()
        client_key = _auth_client_key(request)
        with _AUTH_FAILURES_LOCK:
            bucket = _AUTH_FAILURES.get(client_key)
            if bucket is None:
                return 0
            while bucket and now - bucket[0] >= _AUTH_WINDOW_SECONDS:
                bucket.popleft()
            if not bucket:
                _AUTH_FAILURES.pop(client_key, None)
                return 0
            if len(bucket) < _AUTH_MAX_FAILURES:
                return 0
            return max(1, int(_AUTH_WINDOW_SECONDS - (now - bucket[0]) + 0.999))

    def _record_auth_failure(request: Request) -> int:
        now = time.monotonic()
        client_key = _auth_client_key(request)
        with _AUTH_FAILURES_LOCK:
            for key, old_bucket in list(_AUTH_FAILURES.items()):
                while old_bucket and now - old_bucket[0] >= _AUTH_WINDOW_SECONDS:
                    old_bucket.popleft()
                if not old_bucket:
                    _AUTH_FAILURES.pop(key, None)
            bucket = _AUTH_FAILURES.setdefault(client_key, deque())
            bucket.append(now)
            if len(_AUTH_FAILURES) > _AUTH_MAX_CLIENTS:
                oldest = min(_AUTH_FAILURES, key=lambda key: _AUTH_FAILURES[key][0])
                _AUTH_FAILURES.pop(oldest, None)
            if len(bucket) < _AUTH_MAX_FAILURES:
                return 0
            return max(1, int(_AUTH_WINDOW_SECONDS - (now - bucket[0]) + 0.999))

    def _clear_auth_failures(request: Request) -> None:
        with _AUTH_FAILURES_LOCK:
            _AUTH_FAILURES.pop(_auth_client_key(request), None)

    def _auth_failure_response(retry_after: int = 0) -> JSONResponse:
        if retry_after:
            return JSONResponse(
                {"error": "Too many invalid API-token attempts; retry after the cooldown."},
                status_code=429, headers={"Retry-After": str(retry_after)},
            )
        return JSONResponse(
            {"error": "Unauthorized. Supply an API bearer token or unlock the web console."},
            status_code=401, headers={"WWW-Authenticate": "Bearer"},
        )

    def _https_required_response() -> JSONResponse:
        return JSONResponse(
            {"error": "Network-facing API authentication requires HTTPS. Use a trusted TLS proxy and configure API_TRUST_PROXY_HEADERS=true."},
            status_code=426, headers={"Upgrade": "TLS/1.2, HTTP/1.1"},
        )

    def _token_valid(request: Request) -> bool:
        if not API_AUTH_TOKEN:
            return not _network_exposed(request)
        authorization = request.headers.get("authorization", "")
        bearer = authorization[7:].strip() if authorization.lower().startswith("bearer ") else ""
        supplied = (request.headers.get("x-api-token") or bearer
                    or request.cookies.get("jarvis_api_session") or "")
        return bool(supplied) and hmac.compare_digest(str(supplied), API_AUTH_TOKEN)

    @app.middleware("http")
    async def api_access_guard(request: Request, call_next):
        path = request.url.path
        if path == "/auth":
            retry_after = _auth_retry_after(request)
            if retry_after:
                return _auth_failure_response(retry_after)
            return await call_next(request)
        if path in {"/", "/auth/status", "/auth/logout"}:
            return await call_next(request)
        network_exposed = _network_exposed(request)
        if network_exposed and not API_AUTH_TOKEN:
            return JSONResponse({"error": "API network exposure is disabled until NIKHILAI_API_TOKEN is configured."},
                                status_code=503)
        if network_exposed and not _request_is_https(request):
            return _https_required_response()
        if API_AUTH_TOKEN:
            retry_after = _auth_retry_after(request)
            if retry_after:
                return _auth_failure_response(retry_after)
            if not _token_valid(request):
                return _auth_failure_response(_record_auth_failure(request))
            _clear_auth_failures(request)
        return await call_next(request)

    @app.get("/auth/status")
    async def auth_status(request: Request) -> JSONResponse:
        network_exposed = _network_exposed(request)
        return JSONResponse({"required": bool(API_AUTH_TOKEN) or network_exposed,
                             "authorized": _token_valid(request),
                             "auth_possible": bool(API_AUTH_TOKEN) or not network_exposed})

    @app.post("/auth")
    async def auth_unlock(request: Request) -> JSONResponse:
        network_exposed = _network_exposed(request)
        if not API_AUTH_TOKEN:
            if network_exposed:
                return JSONResponse({"ok": False, "error": "NIKHILAI_API_TOKEN is required for a non-loopback bind."},
                                    status_code=503)
            return JSONResponse({"ok": True, "required": False})
        if network_exposed and not _request_is_https(request):
            return _https_required_response()
        try:
            payload = await request.json()
        except Exception:
            payload = {}
        supplied = str(payload.get("token", "")) if isinstance(payload, dict) else ""
        if not supplied or not hmac.compare_digest(supplied, API_AUTH_TOKEN):
            retry_after = _record_auth_failure(request)
            return JSONResponse({"ok": False, "error": "Invalid API token."}, status_code=429 if retry_after else 401,
                                headers={"Retry-After": str(retry_after)} if retry_after else None)
        _clear_auth_failures(request)
        response = JSONResponse({"ok": True, "required": True})
        response.set_cookie("jarvis_api_session", API_AUTH_TOKEN, httponly=True,
                            secure=network_exposed or _request_is_https(request),
                            samesite="strict", max_age=8 * 60 * 60, path="/")
        return response

    @app.post("/auth/logout")
    async def auth_logout(request: Request) -> JSONResponse:
        response = JSONResponse({"ok": True})
        response.delete_cookie("jarvis_api_session", httponly=True,
                               secure=_network_exposed(request) or _request_is_https(request),
                               samesite="strict", path="/")
        return response

    @app.get("/health")
    async def health() -> JSONResponse:
        return JSONResponse(_status())

    @app.post("/chat")
    async def chat(payload: dict) -> JSONResponse:
        message = (payload or {}).get("message", "").strip()
        session_id = (payload or {}).get("session_id", "web")
        if not message:
            return JSONResponse({"error": "message khali hai"}, status_code=400)
        started = time.time()
        result = (await run_agent(message, session_id=session_id, surface="api")).as_dict()
        return JSONResponse(
            {
                "answer": result.get("answer", ""),
                "spoken": result.get("spoken", ""),
                "workers": result.get("workers", []),
                "plan": result.get("plan", []),
                "findings": [
                    {"worker": f.get("worker"), "summary": str(f.get("summary", ""))[:1200]}
                    for f in result.get("findings", [])
                ],
                "memory_updates": result.get("memory_updates", []),
                "artifacts": result.get("artifacts", []),
                "critique": result.get("critique", {}),
                "iterations": result.get("iterations", 0),
                "errors": result.get("errors", []),
                "status": result.get("status", "unknown"),
                "execution_required": result.get("execution_required", False),
                "verified_execution": result.get("verified_execution", False),
                "memory_persisted": result.get("memory_persisted", False),
                "task_id": result.get("task_id", ""),
                "seconds": round(time.time() - started, 2),
            }
        )

    @app.post("/task")
    async def task(payload: dict) -> JSONResponse:
        message = (payload or {}).get("task", "").strip()
        if not message:
            return JSONResponse({"error": "task khali hai"}, status_code=400)
        result = (await run_agent(message, session_id=(payload or {}).get("session_id", "api"),
                                  surface="api")).as_dict()
        safe = {k: v for k, v in result.items() if k not in ("messages",)}
        return JSONResponse(json.loads(json.dumps(safe, default=str)))

    @app.get("/stream")
    async def stream(message: str = Query(...), session_id: str = "web") -> StreamingResponse:
        async def gen():
            queue: asyncio.Queue = asyncio.Queue()
            loop = asyncio.get_running_loop()
            started = time.monotonic()

            def on_progress(event) -> None:
                payload = {
                    "kind": event.kind, "text": event.text, "tool": event.tool,
                    "status": event.status, "ms": event.ms, "ts": event.ts,
                }
                loop.call_soon_threadsafe(queue.put_nowait, payload)

            yield f"event: start\ndata: {json.dumps({'message': message, 'interface': 'API/server'})}\n\n"
            task = asyncio.create_task(run_agent(message, session_id=session_id,
                                                 surface="api", on_progress=on_progress))
            result_sent = False
            try:
                while not task.done() or not queue.empty():
                    try:
                        payload = await asyncio.wait_for(queue.get(), timeout=15.0)
                        yield f"event: progress\ndata: {json.dumps(payload, default=str)}\n\n"
                    except asyncio.TimeoutError:
                        if task.done():
                            break
                        yield ("event: heartbeat\ndata: "
                               + json.dumps({"elapsed_seconds": round(time.monotonic() - started),
                                             "message": "still waiting; no new runtime event"})
                               + "\n\n")
                result = await task
                final = result.as_dict()
                payload = {
                    "answer": final.get("answer", ""), "spoken": final.get("spoken", ""),
                    "workers": final.get("workers", []), "plan": final.get("plan", []),
                    "memory_updates": final.get("memory_updates", []),
                    "artifacts": final.get("artifacts", []), "errors": final.get("errors", []),
                    "status": final.get("status", "unknown"),
                    "execution_required": final.get("execution_required", False),
                    "verified_execution": final.get("verified_execution", False),
                    "memory_persisted": final.get("memory_persisted", False),
                    "seconds": round(time.monotonic() - started, 2),
                }
                yield f"event: result\ndata: {json.dumps(payload, default=str)}\n\n"
                result_sent = True
            except asyncio.CancelledError:
                if not task.done():
                    task.cancel()
                raise
            except Exception as exc:
                yield f"event: error\ndata: {json.dumps({'error': f'{type(exc).__name__}: {str(exc)[:400]}'})}\n\n"
            finally:
                if not task.done():
                    task.cancel()
                    try:
                        await task
                    except BaseException:
                        pass
            yield f"event: end\ndata: {json.dumps({'result_sent': result_sent})}\n\n"

        return StreamingResponse(gen(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    @app.get("/notes")
    async def notes() -> JSONResponse:
        return JSONResponse({"notes": get_memory().notes(limit=50)})

    @app.get("/tools")
    async def tools() -> JSONResponse:
        from ..tools import describe_tools, tool_names

        return JSONResponse({"count": len(tool_names()), "names": tool_names(), "catalogue": describe_tools()})

    @app.get("/voice")
    async def voice() -> JSONResponse:
        from ..voice.livekit_agent import voice_status

        return JSONResponse(voice_status())

    @app.get("/memory")
    async def memory(limit: int = 30) -> JSONResponse:
        from ..memory.manager import get_manager

        mgr = get_manager()
        return JSONResponse({"stats": mgr.stats(), "memories": mgr.list_memories(limit=limit)})

    @app.post("/memory")
    async def memory_write(payload: dict) -> JSONResponse:
        """{action: remember|forget|update, text: str, id: str}"""
        from ..memory.manager import get_manager

        mgr = get_manager()
        action = (payload or {}).get("action", "remember")
        text = (payload or {}).get("text", "")
        if action == "remember":
            return JSONResponse(mgr.remember(text))
        if action == "forget":
            return JSONResponse(mgr.forget(text, all_matches=bool((payload or {}).get("all"))))
        if action == "update":
            return JSONResponse(mgr.update((payload or {}).get("id", ""), text))
        return JSONResponse({"ok": False, "message": f"unknown action '{action}'"})

    @app.get("/automations")
    async def automations() -> JSONResponse:
        from ..automation import scheduler as sch

        return JSONResponse({"status": sch.status(), "items": sch.get_store().list()})

    @app.get("/graph")
    async def graph() -> JSONResponse:
        return JSONResponse({"mermaid": graph_mermaid(), "summary": graph_summary()})

    @app.get("/", response_class=HTMLResponse)
    async def index() -> str:
        return CONSOLE_HTML


# ---------------------------------------------------------------------------
# Web console (inline everything — sandboxed preview me bhi chalta hai)
# ---------------------------------------------------------------------------
CONSOLE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>NikhilAI Jarvis — Console</title>
<style>
  :root{
    --bg:#070b14; --panel:#0d1424; --panel2:#121b30; --line:#1e2b47;
    --text:#e8eefc; --muted:#8fa3c8; --accent:#4da3ff; --accent2:#7ef0c0;
    --warn:#ffcc66; --err:#ff6b81;
  }
  *{box-sizing:border-box}
  body{margin:0;font-family:ui-sans-serif,system-ui,'Segoe UI',Roboto,sans-serif;background:
      radial-gradient(1200px 600px at 10% -10%, #14213d 0%, transparent 60%), var(--bg);color:var(--text);min-height:100vh}
  header{padding:18px 22px;border-bottom:1px solid var(--line);display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between}
  .brand{display:flex;gap:12px;align-items:center}
  .logo{width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,#4da3ff,#7ef0c0);display:grid;place-items:center;font-weight:800;color:#06101f}
  h1{font-size:17px;margin:0;letter-spacing:.3px}
  .sub{color:var(--muted);font-size:12px}
  .badges{display:flex;gap:8px;flex-wrap:wrap}
  .badge{font-size:11px;padding:4px 9px;border-radius:999px;border:1px solid var(--line);background:var(--panel);color:var(--muted)}
  .badge.on{color:#06101f;background:var(--accent2);border-color:transparent;font-weight:700}
  .badge.off{color:#ffd9de;background:#3a1220;border-color:#5d1e30}
  .badge.info{color:#cfe0ff;background:#111c31;border-color:#28466f}
  main{display:grid;grid-template-columns:1.35fr .95fr;gap:16px;padding:16px;max-width:1400px;margin:0 auto}
  @media (max-width:980px){main{grid-template-columns:1fr}}
  .card{background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:14px;padding:14px}
  .card h2{font-size:13px;margin:0 0 10px;color:var(--muted);text-transform:uppercase;letter-spacing:.12em}
  #log{height:430px;overflow:auto;display:flex;flex-direction:column;gap:10px;padding-right:4px}
  .msg{border:1px solid var(--line);border-radius:12px;padding:10px 12px;white-space:pre-wrap;line-height:1.5;font-size:13.5px}
  .msg.user{background:#0f1a2f;border-color:#22406b}
  .msg.bot{background:#0b1524}
  .msg.sys{background:#0e1526;color:var(--muted);font-size:12px;font-family:ui-monospace,Menlo,monospace}
  .who{font-size:11px;color:var(--muted);margin-bottom:5px;letter-spacing:.08em;text-transform:uppercase}
  .row{display:flex;gap:8px;margin-top:12px}
  input,button,textarea{font:inherit}
  input[type=text]{flex:1;background:#0a1120;border:1px solid var(--line);color:var(--text);border-radius:10px;padding:12px}
  button{background:linear-gradient(135deg,#4da3ff,#7ef0c0);border:none;color:#06101f;font-weight:700;border-radius:10px;padding:12px 16px;cursor:pointer}
  button.ghost{background:#111c31;color:var(--text);border:1px solid var(--line);font-weight:600}
  button:disabled{opacity:.55;cursor:progress}
  .chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
  .chip{font-size:11.5px;padding:6px 10px;border-radius:999px;background:#101b2f;border:1px solid var(--line);color:#bcd0f0;cursor:pointer}
  .chip:hover{border-color:var(--accent)}
  pre{margin:0;white-space:pre-wrap;word-break:break-word;font-size:12px;color:#cfe0ff}
  .kv{display:flex;justify-content:space-between;gap:10px;font-size:12.5px;padding:5px 0;border-bottom:1px dashed #1b2740}
  .kv span:last-child{color:var(--muted)}
  .node{display:flex;gap:8px;align-items:center;font-size:12px;padding:5px 0;color:var(--muted)}
  .dot{width:8px;height:8px;border-radius:50%;background:var(--accent)}
  .dot.done{background:var(--accent2)}
  .dot.err{background:var(--err)}
  .muted{color:var(--muted);font-size:12px}
  .err{color:var(--err)}
  a{color:var(--accent)}
</style>
</head>
<body>
<header>
  <div class="brand">
    <div class="logo">NJ</div>
    <div>
      <h1>NikhilAI Jarvis — Console</h1>
      <div class="sub">LangGraph supervisor • DSPy reasoning • browser-use agents • self-healing code engine</div>
    </div>
  </div>
  <div class="badges" id="badges"></div>
</header>

<section id="auth-panel" class="card" hidden style="max-width:760px;margin:16px auto">
  <h2>API access</h2>
  <div class="muted" id="auth-message">This server requires an API token.</div>
  <div class="row">
    <input id="api-token" type="password" autocomplete="current-password" placeholder="NIKHILAI_API_TOKEN"/>
    <button id="unlock">Unlock</button>
  </div>
</section>

<main>
  <section class="card">
    <h2>Chat / Command</h2>
    <div id="log"></div>
    <div class="row">
      <input id="q" type="text" placeholder="jarvis, alag alag website se laptop prices laao aur laptops naam se notes me save kardo"/>
      <button id="send" disabled>Run</button>
      <button id="cancel" class="ghost" disabled>Cancel</button>
    </div>
    <div class="chips">
      <div class="chip">notepad me meeting_notes naam se save kardo: client call 5 baje</div>
      <div class="chip">ek script likho jo csv report bana de</div>
      <div class="chip">browser se laptop ke top 5 price laao aur laptops naam se save kardo</div>
      <div class="chip">yaad rakhna mera client Ramesh hai</div>
      <div class="chip">tum kaun ho?</div>
    </div>
  </section>

  <section class="card">
    <h2>Runtime</h2>
    <div id="status"></div>
    <h2 style="margin-top:14px">Live runtime events</h2>
    <div id="trace"><div class="muted">Koi run nahi hua abhi.</div></div>
    <h2 style="margin-top:14px">Notes</h2>
    <div id="notes"><div class="muted">—</div></div>
    <h2 style="margin-top:14px">API</h2>
    <div class="muted">
      POST <code>/chat</code> · POST <code>/task</code> · GET <code>/stream</code> ·
      GET <code>/health</code> · GET <code>/tools</code> · GET <code>/graph</code>
    </div>
  </section>
</main>

<script>
const $ = (id) => document.getElementById(id);
let busy = false;
let activeStream = null;
let apiAuthReady = false;

function bubble(kind, who, text){
  const div = document.createElement('div');
  div.className = 'msg ' + kind;
  const label = document.createElement('div'); label.className = 'who'; label.textContent = who;
  const body = document.createElement('div'); body.textContent = String(text ?? '');
  div.append(label, body); $('log').appendChild(div);
  $('log').scrollTop = $('log').scrollHeight;
  return div;
}
function escapeHtml(s){
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function setBusy(on){
  busy = on; $('send').disabled = on || !apiAuthReady; $('cancel').disabled = !on;
}
async function initAuth(){
  const panel = $('auth-panel');
  try{
    const r = await fetch('./auth/status');
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
    apiAuthReady = !!d.authorized;
    if (!d.required || apiAuthReady){
      panel.hidden = true; setBusy(false); loadStatus(); loadNotes(); return;
    }
    panel.hidden = false;
    $('auth-message').textContent = d.auth_possible
      ? 'Enter NIKHILAI_API_TOKEN. The browser keeps it only for this login session; it is not placed in the URL.'
      : 'This server is bound beyond loopback but NIKHILAI_API_TOKEN is not configured. Requests are fail-closed.';
    setBusy(false);
  }catch(e){
    panel.hidden = false; $('auth-message').textContent = 'Could not check API access: ' + String(e);
    apiAuthReady = false; setBusy(false);
  }
}
async function unlockApi(){
  const button = $('unlock'); button.disabled = true;
  try{
    const r = await fetch('./auth', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({token: $('api-token').value})});
    const d = await r.json();
    if (!r.ok || !d.ok) throw new Error(d.error || ('HTTP ' + r.status));
    apiAuthReady = true; $('api-token').value = ''; $('auth-panel').hidden = true;
    setBusy(false); loadStatus(); loadNotes();
  }catch(e){ $('auth-message').textContent = 'Unlock failed: ' + String(e); }
  finally{ button.disabled = false; }
}
async function loadStatus(){
  try{
    const r = await fetch('./health'); if (!r.ok) throw new Error('HTTP ' + r.status);
    const d = await r.json();
    const b = $('badges'); b.innerHTML = '';
    const addBadge = (label, tone='info') => {
      const el = document.createElement('div'); el.className = 'badge ' + tone;
      el.textContent = label; b.appendChild(el);
    };
    addBadge('Interface: ' + (d.interface || 'API/server'));
    addBadge('Readiness: ' + (d.status || 'unknown'), d.offline_demo ? 'off' : 'info');
    addBadge('Provider: ' + d.provider + ' • ' + (d.provider_status || 'connectivity not tested'));
    addBadge('Browser: ' + (d.browser || 'unknown'), d.browser_use ? 'info' : 'off');
    addBadge('LiveKit: ' + (d.livekit_status || 'unknown'), d.livekit ? 'info' : 'off');
    addBadge('Telegram: ' + (d.telegram_status || 'unknown'), d.telegram ? 'info' : 'off');
    const s = $('status'); s.innerHTML = '';
    const rows = [
      ['Operator / Owner', d.owner], ['Assistant', d.assistant], ['Interface', d.interface],
      ['Readiness', d.status], ['Provider', d.provider], ['Configured provider', d.configured_provider],
      ['Brain model', d.model], ['Fast model', d.fast_model], ['Provider status', d.provider_status],
      ['Tools', d.tools + ' schemas registered; per-interface permissions apply'],
      ['Browser', d.browser], ['Voice (LiveKit)', d.livekit_status], ['Telegram', d.telegram_status],
      ['Memory facts / episode records', (d.memory?.facts ?? 0) + ' / ' + (d.memory?.episodes ?? 0)],
      ['Notes indexed', d.memory?.notes ?? 0], ['Automations', d.automations], ['Workspace', d.workspace],
      ['Connectivity', d.connectivity_tested ? 'tested' : 'not tested by status endpoint']
    ];
    for (const [k, v] of rows){
      const div = document.createElement('div'); div.className = 'kv';
      const key = document.createElement('span'); key.textContent = k;
      const value = document.createElement('span'); value.textContent = String(v ?? '—');
      div.append(key, value); s.appendChild(div);
    }
  }catch(e){ bubble('sys', 'status error', String(e)); }
}
async function loadNotes(){
  try{
    const r = await fetch('./notes'); const d = await r.json();
    const el = $('notes'); el.innerHTML = '';
    if (!d.notes || !d.notes.length){ el.innerHTML = '<div class="muted">Abhi koi note nahi.</div>'; return; }
    for (const n of d.notes.slice(0, 8)){
      const div = document.createElement('div'); div.className = 'node';
      const dot = document.createElement('span'); dot.className = 'dot';
      const label = document.createElement('span'); label.textContent = `${n.name} ${n.size || ''}B`;
      div.append(dot, label); el.appendChild(div);
    }
  }catch(e){}
}
function traceStep(kind, detail, status=''){
  const el = $('trace');
  if (el.querySelector('.muted')) el.innerHTML = '';
  const div = document.createElement('div'); div.className = 'node';
  const dot = document.createElement('span'); dot.className = 'dot';
  if (status === 'ok' || kind === 'done') dot.classList.add('done');
  if (status === 'fail' || kind === 'error') dot.classList.add('err');
  const title = document.createElement('b'); title.textContent = kind;
  const text = document.createElement('span'); text.className = 'muted'; text.textContent = detail || '';
  div.append(dot, title, text); el.appendChild(div);
  el.scrollTop = el.scrollHeight;
}
function stopStream(message='Cancelled by user.'){
  if (activeStream){ activeStream.close(); activeStream = null; }
  if (busy){ bubble('sys', 'cancelled', message); setBusy(false); }
}
function run(){
  const message = $('q').value.trim();
  if (!message || busy) return;
  setBusy(true);
  bubble('user', 'Owner (Nikhil Mehra)', message);
  $('q').value = '';
  const waiting = bubble('sys', 'runtime', 'Request accepted; waiting for actual runtime events…');
  $('trace').innerHTML = '<div class="muted">Waiting for server events…</div>';
  const params = new URLSearchParams({message, session_id:'web'});
  const stream = new EventSource('./stream?' + params.toString());
  activeStream = stream;
  let resultReceived = false;
  const parse = ev => { try { return JSON.parse(ev.data || '{}'); } catch { return {}; } };
  const close = () => {
    stream.close(); if (activeStream === stream) activeStream = null;
    setBusy(false);
  };
  stream.addEventListener('start', ev => {
    const d = parse(ev); waiting.querySelector('div:last-child').textContent =
      'Request started on ' + (d.interface || 'server') + '; progress will appear only when emitted.';
    traceStep('request_start', d.interface || 'API/server', 'ok');
  });
  stream.addEventListener('progress', ev => {
    const d = parse(ev); const label = d.text || d.tool || 'runtime event';
    waiting.querySelector('div:last-child').textContent = label;
    traceStep(d.kind || 'progress', label + (d.ms ? ` • ${d.ms}ms` : ''), d.status || '');
  });
  stream.addEventListener('heartbeat', ev => {
    const d = parse(ev);
    waiting.querySelector('div:last-child').textContent =
      `Still processing • ${d.elapsed_seconds || 0}s • no new runtime event`;
  });
  stream.addEventListener('result', ev => {
    const d = parse(ev); resultReceived = true; waiting.remove();
    const meta = [`status: ${d.status || 'unknown'}`];
    if (d.workers?.length) meta.push('workers: ' + d.workers.join(', '));
    if (d.memory_updates?.length) meta.push('memory updates: ' + d.memory_updates.join(', '));
    if (d.artifacts?.length) meta.push('artifacts: ' + d.artifacts.length);
    if (d.memory_persisted) meta.push('turn memory persisted');
    else meta.push('memory persistence not confirmed');
    if (d.execution_required) meta.push(d.verified_execution ? 'tool evidence verified' : 'tool completion not verified');
    if (d.seconds != null) meta.push(d.seconds + 's');
    bubble('bot', 'Jarvis', (d.answer || '(no answer returned)') + '\n\n— ' + meta.join(' • '));
    if (d.errors?.length) bubble('sys', 'errors', d.errors.join('\n'));
    const terminal = (d.status || 'unknown').toLowerCase();
    const failedStates = new Set(['failed','error','blocked','cancelled','partial_failure','done_with_errors']);
    const successfulStates = new Set(['done','chat','memory','settings','time']);
    const terminalTone = failedStates.has(terminal) ? 'fail'
      : terminal === 'needs_clarification' ? 'skipped'
      : successfulStates.has(terminal) ? 'ok' : '';
    traceStep('result', 'terminal status: ' + terminal, terminalTone);
    loadNotes(); loadStatus(); close();
  });
  stream.addEventListener('error', ev => {
    if (ev.data){
      const d = parse(ev); bubble('sys', 'server error', d.error || 'Server reported an error.');
      traceStep('error', d.error || 'server error', 'fail'); waiting.remove();
    }else if (!resultReceived && stream.readyState === EventSource.CLOSED){
      waiting.remove(); bubble('sys', 'connection error', 'Stream closed before a final result arrived.');
      traceStep('connection_error', 'no final result received', 'fail'); close();
    }
  });
  stream.addEventListener('end', ev => {
    const d = parse(ev);
    if (!resultReceived){
      waiting.remove(); bubble('sys', 'incomplete', 'Stream ended without a final result.');
      traceStep('incomplete', JSON.stringify(d), 'fail');
    }
    close();
  });
}
$('send').onclick = run;
$('cancel').onclick = () => stopStream('Cancel requested; live stream closed. Server cancellation is best-effort.');
$('unlock').onclick = unlockApi;
$('q').addEventListener('keydown', e => { if (e.key === 'Enter') run(); });
$('api-token').addEventListener('keydown', e => { if (e.key === 'Enter') unlockApi(); });
document.querySelectorAll('.chip').forEach(c => c.onclick = () => { $('q').value = c.textContent; run(); });
initAuth();
</script>
</body>
</html>
"""


def main() -> int:
    if not fastapi_available:
        print("⚠️ FastAPI/uvicorn install karo: pip install fastapi uvicorn")
        return 1
    import uvicorn

    print(f"\n🤖 {ASSISTANT_NAME} console → http://{API_HOST}:{API_PORT}\n")
    uvicorn.run(app, host=API_HOST, port=API_PORT, log_level="info")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
